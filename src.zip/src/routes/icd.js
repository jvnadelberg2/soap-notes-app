import express from "express";
import { suggestICD } from "../services/icd.js";
import { findICDStrict } from "../services/icd.js";
import { findICDGeneral } from "../services/icd.js";
import { findBestICD } from "../services/icd.js";

const router = express.Router();

function tokenize(s){
  return new Set(String(s||"").toLowerCase().match(/[a-z0-9]+/g)||[]);
}
function hasAny(s, arr){
  const L=String(s||"").toLowerCase();
  return arr.some(w=>new RegExp("\\b"+w.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"\\b","i").test(L));
}
function scoreEntry(e, textTokens, textRaw){
  const term=String(e.term||e.name||e.label||"").toLowerCase();
  const termToks=term.match(/[a-z0-9]+/g)||[];
  let score=0;
  for(const tok of termToks){ if(textTokens.has(tok)) score+=1; }
  const hasHeadache = hasAny(textRaw, ["headache","migraine","photophobia","phonophobia","aura","throbbing","head pain"]);
  const hasUrinary  = hasAny(textRaw, ["urinary","dysuria","frequency","urgency","hematuria","suprapubic","flank","pyelo","cystitis","burning urination"]);
  if(hasHeadache && !hasUrinary && /\b(uti|urinary|cystitis|pyelonephritis)\b/i.test(term)) score-=5;
  if(hasUrinary && !hasHeadache && /\b(headache|migraine)\b/i.test(term)) score-=3;
  return score;
}

router.post("/icd-suggest", (req, res) => {
  const { text = "", limit = 8 } = req.body || {};
  const base = suggestICD({ text, limit: Math.max(limit, 20) }) || [];
  const tokens = tokenize(text);
  const ranked = base
    .map(x => ({ x, s: scoreEntry(x, tokens, text) }))
    .sort((a,b) => b.s - a.s)
    .map(o => o.x)
    .slice(0, limit);
  res.json({ icd: ranked });
});

export default router;


router.get("/icd-codes", (req, res) => {
  try {
    const { getICDIndex } = require("../services/icd.js");
  } catch(_){}

  const mod = require("../services/icd.js");
  const all = (mod.getICDIndex && mod.getICDIndex()) || [];
  const q = String(req.query.q || "").toLowerCase();
  const limit = Math.min(Math.max(parseInt(req.query.limit || "50", 10), 1), 200);
  const offset = Math.max(parseInt(req.query.offset || "0", 10), 0);

  let filtered = all;
  if (q) {
    filtered = all.filter(r => {
      const code = String(r.code || r.Code || "").toLowerCase();
      const desc = String(r.desc || r.description || r.Title || "").toLowerCase();
      return code.startsWith(q) || desc.includes(q);
    });
  }

  const total = filtered.length;
  const results = filtered.slice(offset, offset + limit).map(r => ({
    code: r.code || r.Code || "",
    desc: r.desc || r.description || r.Title || ""
  }));

  res.json({
    total,
    offset,
    limit,
    has_more: offset + results.length < total,
    results
  });
});


router.post("/icd-best", (req, res) => {
  try {
    const body = req.body || {};
    const text = String(body.text || body.query || body.description || "").trim();
    const lim  = Math.max(1, Math.min(200, parseInt(body.limit ?? "10", 10)));
    const ranked = findBestICD({ text, limit: lim }) || [];
    res.json({ icd: ranked, total: ranked.length });
  } catch (e) {
    res.status(500).json({ error: String(e && e.message || e) });
  }
});

router.post("/icd-search", (req, res) => {
  try {
    const b=req.body||{};
    const t=String(b.text||b.query||b.description||"").trim();
    const lim=Math.max(1,Math.min(200,parseInt(b.limit??"10",10)));
    const ranked=findICDGeneral({text:t,limit:lim})||[];
    res.json({icd:ranked,total:ranked.length});
  } catch(e){
    res.status(500).json({error:String(e&&e.message||e)});
  }
});

router.post("/icd-search-strict", (req, res) => {
  try{
    const b=req.body||{};
    const t=String(b.text||b.query||b.description||"").trim();
    const lim=Math.max(1,Math.min(200,parseInt(b.limit??"10",10)));
    const ranked=findICDStrict({text:t,limit:lim})||[];
    res.json({icd:ranked,total:ranked.length});
  }catch(e){
    res.status(500).json({error:String(e&&e.message||e)});
  }
});
