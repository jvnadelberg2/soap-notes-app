import express from "express";
import { generateSoapNoteJSON } from "../services/ai.js";
import { suggestICD } from "../services/icd.js";
import { lookupICD } from "../services/icd.js";
import { findICDStrict } from "../services/icd.js";
import { findICDGeneral } from "../services/icd.js";

const router = express.Router();

router.post("/generate-soap-json-annotated", async (req, res) => {
  try {
    const { rawText = "", patientHistory = "", specialty = "General Practice", vitals = null, labs = null, imaging = null, allowInference = false, limit = 8, model = null, provider = "ollama" } = req.body || {};
    const data = await generateSoapNoteJSON({ rawText, patientHistory, specialty, vitals, labs, imaging, allowInference, model, provider });
    const textForICD = [data.Subjective, data.Objective, data.Assessment, data.Plan].filter(Boolean).join(" | ");
  .map(r => {
    const code = String((r && (r.code||r.Code||r)) || "").toUpperCase();
    const desc = lookupICD(code) || (r && r.desc) || "";
    return code ? { code, desc } : null;
  })
  .filter(Boolean);
    const textForICD=[data && data.Subjective,data && data.Objective,data && data.Assessment,data && data.Plan].filter(Boolean).join(" | ");
  const code=String((r&&(r.code||r.Code||r))||"").toUpperCase();
  const desc=lookupICD(code)||(r&&r.desc)||"";
  return code?{code,desc}:null;
}).filter(Boolean);
const textForICD = [data && data.Subjective, data && data.Objective, data && data.Assessment, data && data.Plan].filter(Boolean).join(" | ");
let icdStrict = [];
try { icdStrict = findICDStrict({ text: textForICD, limit: Math.max(limit || 0, 20) }) || []; } catch (_) { icdStrict = []; }
const _arr = Array.isArray(icdStrict) ? icdStrict : (icdStrict && Array.isArray(icdStrict.icd) ? icdStrict.icd : []);
const icdClean = _arr.map(r => {
  const code = String((r && (r.code || r.Code || r)) || "").toUpperCase();
  const desc = lookupICD(code) || (r && r.desc) || "";
  return code ? { code, desc } : null;
}).filter(Boolean);
res.json({ data, icd: icdClean, meta: { specialty, allowInference, model, provider } });
  } catch (e) {
    console.error(e);
    console.error("ANNOTATED ERROR:", (e && e.stack) || e);
const errMsg = (e && (e.message || e.toString())) || "Annotated generation failed";
res.status(500).json({ error: errMsg });
  }
});

export default router;
