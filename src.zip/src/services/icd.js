import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const IDX_PATH = path.resolve(__dirname, "../../data/icd10_index.json");

let __ICD_INDEX = null;
function loadIndexOnce(){
  if (__ICD_INDEX) return __ICD_INDEX;
  try {
    const raw = fs.readFileSync(IDX_PATH, "utf8");
    __ICD_INDEX = JSON.parse(raw);
  } catch (e) {
    __ICD_INDEX = [];
  }
  return __ICD_INDEX;
}
export function getICDIndex(){
  return loadIndexOnce();
}

function tokenize(s){
  return String(s||"")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g," ")
    .split(/\s+/)
    .filter(w => w.length >= 3 && !["and","the","with","without","unspecified","acute","chronic","other"].includes(w));
}
function buildKeywords(term){
  const base = tokenize(term);
  const extra = [];
  if (/myocardial infarction|mi\b/.test(term.toLowerCase())) extra.push("mi","myocardial infarction","heart attack","stemi","nstemi","troponin");
  if (/hypertension|high blood pressure|htn/.test(term.toLowerCase())) extra.push("hypertension","htn","high bp","elevated blood pressure");
  if (/chest pain/.test(term.toLowerCase())) extra.push("chest pain","cp","angina","pressure");
  return Array.from(new Set([...base, ...extra]));
}
function scoreFor(text, entry){
  const t = String(text||"").toLowerCase();
  let s = 0;
  for (const k of entry.keywords || []) if (t.includes(String(k).toLowerCase())) s++;
  return s;
}
export function loadIndex(){
  try { return JSON.parse(fs.readFileSync(IDX_PATH,"utf8")); } catch { return []; }
}
export function writeICDIndex(entries){
  fs.writeFileSync(IDX_PATH, JSON.stringify(entries, null, 2));
  return true;
}
export function buildIndexFromSimpleCSV(csv){
  const out = [];
  const lines = String(csv||"").split(/\r?\n/).filter(Boolean);
  let i = 0;
  for (const line of lines){
    i++;
    if (i === 1 && /^code\s*,\s*term/i.test(line)) continue;
    const m = line.split(",");
    if (m.length < 2) continue;
    const code = m.shift().trim();
    const term = m.join(",").trim();
    if (!code || !term) continue;
    out.push({ code, term, keywords: buildKeywords(term) });
  }
  return out;
}
export function suggestICD({ text, limit = 8 }){
  const INDEX = loadIndex();
  const scored = INDEX.map(e => ({ ...e, score: scoreFor(text, e) })).filter(e => e.score > 0);
  scored.sort((a,b) => b.score - a.score || a.code.localeCompare(b.code));
  return scored.slice(0, limit);
}


export function findBestICD({ text, limit = 10 }){
  const idx = (typeof getICDIndex === 'function' ? getICDIndex() : []);
  const q = String(text||'').trim();
  if(!q) return [];

  function norm(s){ return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim() }
  function toks(s){ return norm(s).split(/\s+/).filter(Boolean) }

  // light synonyms/expansions to catch common wording
  const expMap = {
    bleeding: ['hemorrhage','bleed','bleeding'],
    hemorrhage: ['hemorrhage','bleed','bleeding'],
    rectum: ['rectum','rectal','anus'],
    rectal: ['rectum','rectal','anus'],
    anus: ['anus','rectum','rectal'],
    pain: ['pain','painful','algia'],
    inserted: ['foreign','body'],
    foreign: ['foreign','body'],
    body: ['foreign','body']
  };

  const qTokens = toks(q);
  const qSet = new Set(qTokens.flatMap(w => expMap[w] || [w]));
  const qNorm = Array.from(qSet).join(' ');
  const hasPhraseForeignBody = /\bforeign body\b/i.test(q);

  const scored = [];

  for(const r of idx){
    const code = String(r.code || r.Code || '');
    const desc = String(r.desc || r.description || r.Title || '');
    if(!code || !desc) continue;

    const dn = norm(desc);
    const dToks = toks(desc);
    const dSet = new Set(dToks);

    // token overlap
    let overlap = 0;
    for(const w of qSet){ if(dSet.has(w)) overlap++; }

    // phrase/feature boosts
    let score = 0;
    if (hasPhraseForeignBody && /\bforeign body\b/.test(dn)) score += 12;
    // direct inclusion of normalized query string
    if (dn.includes(qNorm)) score += 8;
    // code-string hints in query
    const codeLower = code.toLowerCase();
    const qLower = q.toLowerCase();
    if (qLower.startsWith(codeLower)) score += 30;
    else if (qLower.includes(codeLower)) score += 10;

    // overlap weight
    score += overlap * 4;

    if (score > 0){
      scored.push({ code, desc, score });
    }
  }

  scored.sort((a,b)=> b.score - a.score || a.code.localeCompare(b.code));
  const L = Math.max(1, Math.min(200, limit|0 || 10));
  return scored.slice(0, L);
}



function _norm(x){return String(x||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()}
function _toks(x){return _norm(x).split(/\s+/).filter(Boolean)}
const _syn={bleeding:['bleeding','hemorrhage','bleed','hemorrhagic'],hemorrhage:['bleeding','hemorrhage','bleed','hemorrhagic'],rectum:['rectum','rectal','anus','anal'],rectal:['rectum','rectal','anus','anal'],anus:['rectum','rectal','anus','anal'],pain:['pain','painful','algia'],foreign:['foreign','body','foreignbody'],inserted:['inserted','insertion','retained','lodged'],retained:['retained','lodged'],fever:['fever','pyrexia'],cough:['cough','coughing']}
function _expandTokens(ts){const out=new Set();for(const w of ts){const a=_syn[w]||[w];for(const v of a) out.add(v)}return Array.from(out)}
function _dottedBase(c){const C=String(c||'').toUpperCase();let m;m=/^([A-Z])(\d)(\d)([A-Z0-9])$/.exec(C);if(m)return m[1]+m[2]+m[3]+'.'+m[4];m=/^([A-Z])(\d)(\d)([A-Z0-9])([A-Z0-9])$/.exec(C);if(m)return m[1]+m[2]+m[3]+'.'+m[4]+m[5];return C}
function _suffix(desc){const m=/\bXX([ADS])\b/i.exec(String(desc||''));return m?('XX'+m[1].toUpperCase()):''}
function _cleanDesc(d){return String(d||'').replace(/^\s*XX[ADS]\s+\d+\s+/i,'').replace(/^\s*\d+\s+\d+\s+/,'').trim()}

let __DER=null
function _buildDerived(){
  if(__DER) return __DER
  const idx=(typeof getICDIndex==='function'?getICDIndex():[])
  const rows=[]
  const df=new Map()
  for(const r of idx){
    const code=String(r.code||r.Code||'')
    const desc=String(r.desc||r.description||r.Title||'')
    if(!code||!desc) continue
    const tok=new Set(_toks(desc))
    rows.push({code,desc,tok})
    for(const w of tok){df.set(w,(df.get(w)||0)+1)}
  }
  const N=rows.length||1
  const idf=new Map()
  for(const [w,dfv] of df.entries()){idf.set(w,Math.log(1+N/(dfv+1)))}
  __DER={rows,idf}
  return __DER
}

export function findICDGeneral({text,limit=10}){
  const q=String(text||'').trim()
  if(!q) return []
  const {rows,idf}=_buildDerived()
  const qTokens=_expandTokens(_toks(q))
  const qSet=new Set(qTokens)
  const qNorm=Array.from(qSet).join(' ')
  const hasFB=/\bforeign body\b/i.test(q)
  const scored=[]
  for(const r of rows){
    let overlap=0, wsum=0
    for(const w of qSet){
      if(r.tok.has(w)){ overlap++; wsum+=(idf.get(w)||1) }
    }
    let score=overlap*3+wsum
    const dn=_norm(r.desc)
    if(dn.includes(qNorm)) score+=8
    if(hasFB && /\bforeign body\b/.test(dn)) score+=12
    if(score>0){ scored.push({code:r.code,desc:r.desc,score}) }
  }
  scored.sort((a,b)=> b.score-a.score || a.code.localeCompare(b.code))
  const L=Math.max(1,Math.min(200,limit|0||10))
  return scored.slice(0,L).map(x=>{
    const base=_dottedBase(x.code)
    const suf=_suffix(x.desc)
    return {code:(suf?base+suf:base),desc:_cleanDesc(x.desc),score:x.score}
  })
}



export function findICDStrict({text,limit=10}){
  const q=String(text||'').trim()
  if(!q) return []
  const {rows,idf}=_buildDerived()
  const qTokens=_expandTokens(_toks(q))
  const qSet=new Set(qTokens)
  const qNorm=Array.from(qSet).join(' ')
  const hasFB=/\bforeign body\b/i.test(q)
  const scored=[]
  for(const r of rows){
    let overlap=0, wsum=0
    for(const w of qSet){
      if(r.tok.has(w)){ overlap++; wsum+=(idf.get(w)||1) }
    }
    let score=overlap*3+wsum
    const dn=_norm(r.desc)
    if(dn.includes(qNorm)) score+=8
    if(hasFB && /\bforeign body\b/.test(dn)) score+=12
    if(score>0){ scored.push({code:r.code,desc:r.desc,score}) }
  }
  scored.sort((a,b)=> b.score-a.score || a.code.localeCompare(b.code))
  const L=Math.max(1,Math.min(200,limit|0||10))
  const outRaw=scored.slice(0,L).map(x=>{
    const base=_dottedBase(x.code)
    const suf=_suffix(x.desc)
    const finalCode=suf?base+suf:base
    return { code: finalCode, desc: String(x.desc||'').trim(), score:x.score }
  })
  const byCode=new Map()
  for(const r of outRaw){
    if(!r.desc) continue
    if(!byCode.has(r.code) || r.score>byCode.get(r.code).score) byCode.set(r.code,r)
  }
  return Array.from(byCode.values())
}


function _lookupDesc(code){
  const idx=(typeof getICDIndex==='function'?getICDIndex():[]);
  const C=String(code||'').toUpperCase();
  const nodot=C.replace('.','');
  for(const r of idx){
    const rc=String(r.code||r.Code||'').toUpperCase();
    if(rc===C || rc===nodot || rc.replace('.','')===nodot){
      const d=String(r.desc||r.description||r.Title||'').trim();
      if(d) return d;
    }
  }
  return "";
}

function _normalizeICDCode(c){
  const C=String(c||'').toUpperCase().trim();
  const noXX = C.replace(/XX[ADS]$/i,'');
  return { raw:C, noXX, ndot:noXX.replace('.','') };
}

let __ICD_MAP=null;
export function getICDMap(){
  if(__ICD_MAP) return __ICD_MAP;
  const idx=(typeof getICDIndex==='function'?getICDIndex():[]);
  const m=new Map();
  for(const r of idx){
    const code=String(r.code||r.Code||'').toUpperCase();
    const desc=String(r.desc||r.description||r.Title||'');
    if(!code||!desc) continue;
    const ndot=code.replace('.','');
    m.set(code,desc);
    m.set(ndot,desc);
  }
  __ICD_MAP=m;
  return __ICD_MAP;
}

export function lookupICD(code){
  const m=getICDMap();
  const {raw,noXX,ndot}=_normalizeICDCode(code);
  return m.get(raw) || m.get(noXX) || m.get(ndot) || "";
}
