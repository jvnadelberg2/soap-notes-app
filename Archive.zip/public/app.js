(function(){
  function el(id){return document.getElementById(id)}
  function val(id){const x=el(id);return x?x.value.trim():""}
  function checked(id){const x=el(id);return x?x.checked:false}
  function outEl(){return document.getElementById("soapTextOut")||document.getElementById("jsonOut")}

  
function parseVitalsFrom(text){
  const out={}; const T=String(text||""); let m;
  m=T.match(/\b(?:BP|blood\s*pressure)\s*[:=\s]\s*([0-9]{2,3}\s*[\/\-]\s*[0-9]{2,3})(?!\d)\b/i); if(m) out.BP=m[1].replace(/\s+/g,'');
  m=T.match(/\b(?:HR|heart\s*rate|pulse)\s*[:=\s]\s*([0-9]{2,3})(?!\d)\b/i); if(m) out.HR=m[1];
  m=T.match(/\b(?:RR|resp(?:iratory)?(?:\s*rate)?|resp(?:irations)?)\s*[:=\s]\s*([0-9]{1,3})(?!\d)\b/i); if(m) out.RR=m[1];
  m=T.match(/\b(?:T|temp(?:erature)?)\s*[:=\s]\s*([0-9]{2,3}(?:\.[0-9])?)\s*(?:[FC])?\b/i); if(m) out.Temp=m[1];
  m=T.match(/\b(?:SpO2|SaO2|O2(?:\s*saturation)?)\s*[:=\s]\s*([0-9]{2,3})\s*%\b/i); if(m) out.SpO2=m[1]+"%";
  return out;
}


  const VITAL_KEYS=new Set(["BP","BLOOD PRESSURE","HR","PULSE","RR","RESP","RESPIRATIONS","SPO2","SAO2","O2","TEMP","TEMPERATURE"]);
  function parseLabsList(text){
    const out={}; const T="\n"+String(text||"")+"\n";
    const re=/(^|\n)\s*([A-Za-z][A-Za-z0-9 /+\-%]{1,32})\s*(?::|=)\s*([^\n,;]+)(?=\n|$|,|;)/g;
    let m;
    while((m=re.exec(T))){
      const k=m[2].trim().replace(/\s+/g,' ');
      if(VITAL_KEYS.has(k.toUpperCase())) continue;
      const v=m[3].trim();
      if(k && v) out[k]=v;
    }
    return out;
  }

  function labsTextareaToObj(txt){
    const out={};
    (String(txt||"").split(/\r?\n/)).forEach(line=>{
      const i=line.indexOf("="); if(i<=0) return;
      const k=line.slice(0,i).trim(); const v=line.slice(i+1).trim();
      if(k && v) out[k]=v;
    });
    return out;
  }

  function objToLabsLines(obj){
    return Object.entries(obj).map(([k,v])=>`${k}=${v}`).join("\n");
  }

  function buildPayload(){
    const payload={
      rawText: val('rawText'),
      patientHistory: val('patientHistory'),
      specialty: (el('specialty')?.value)||'General Practice',
      allowInference: checked('allowInference'),
      model: (el('model')?.value)||null
    };
    const vitals={};
    if(val('vBP')) vitals.BP=val('vBP');
    if(val('vHR')) vitals.HR=val('vHR');
    if(val('vRR')) vitals.RR=val('vRR');
    if(!Object.keys(vitals).length){
      Object.assign(vitals, parseVitalsFrom(payload.rawText+"\n"+payload.patientHistory));
    }
    if(Object.keys(vitals).length) payload.vitals=vitals;

    let labs=labsTextareaToObj(val('labs'));
    if(!Object.keys(labs).length){
      labs=parseLabsList(payload.rawText+"\n"+payload.patientHistory);
    }
    if(Object.keys(labs).length) payload.labs=labs;

    const imaging=(el('imaging')?.value||'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
    if(imaging.length) payload.imaging=imaging;

    return payload;
  }
  window.buildPayload = window.buildPayload || buildPayload;
function showNoteText(text){
    const out=outEl(); if(!out) return;
    out.textContent = text || "No output.";
    out.style.whiteSpace='pre-wrap';
    out.style.overflowWrap='anywhere';
    out.style.maxWidth='100%';
    out.style.background='#fff';
  }

  function showICD(list){
    const box=el('icdOut'); if(!box) return;
    const enabled=checked('includeICD');
    if(!enabled){ box.textContent='ICD-10 suggestions disabled.'; return; }
    if(!Array.isArray(list) || !list.length){ box.textContent='No suggestions.'; return; }
    box.innerHTML='<ul>'+list.map(x=>`<li><b>${x.code}</b> — ${x.term}</li>`).join('')+'</ul>';
  }

  async function generate(){
  const status=document.getElementById('status'); if(status) status.textContent='Streaming...';
  try{
    const payload = window.buildPayload();
    const icdPromise=fetch('/api/generate-soap-json-annotated',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}).then(r=>r.json()).catch(()=>null);

    const r=await fetch('/api/generate-soap-stream',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const reader=r.body.getReader();
    const dec=new TextDecoder();
    const out=document.getElementById('soapTextOut')||document.getElementById('jsonOut');

    let buf=''; let painting=false;
    function paint(){ if(painting) return; painting=true; requestAnimationFrame(function(){ if(out) out.textContent=buf; painting=false; }); }

    for(;;){
      const z=await reader.read();
      if(z.done) break;
      buf+=dec.decode(z.value,{stream:true});
      paint();
    }
    if(out) out.textContent=buf;

    const j=await icdPromise;
    if(j&&Array.isArray(j.icd)){
      const box=document.getElementById('icdOut');
      if(box) box.innerHTML=j.icd.length?('<ul>'+j.icd.map(x=>'<li><b>'+x.code+'</b> — '+x.term+'</li>').join('')+'</ul>'):'No suggestions.';
    }
  }catch(e){
    const out=document.getElementById('soapTextOut')||document.getElementById('jsonOut');
    if(out) out.textContent='Error: '+e.message;
  }finally{
    if(status) status.textContent='';
  }
}

  function autofillFromHPI(){
    const hpi = val('rawText')+"\n"+val('patientHistory');
    const v=parseVitalsFrom(hpi);
    if(v.BP && !val('vBP')) el('vBP').value=v.BP;
    if(v.HR && !val('vHR')) el('vHR').value=v.HR;
    if(v.RR && !val('vRR')) el('vRR').value=v.RR;
    if(!val('labs')){
      const labs=parseLabsList(hpi);
      if(Object.keys(labs).length) el('labs').value = objToLabsLines(labs);
    }
  }

  function savePrefs(){
    try{
      const m=el('model'); const s=el('specialty'); const ai=el('allowInference');
      if(m) localStorage.setItem('model', m.value||'');
      if(s) localStorage.setItem('specialty', s.value||'');
      if(ai) localStorage.setItem('allowInference', ai.checked ? '1' : '0');
    }catch(e){}
  }
  function loadPrefs(){
    try{
      const sm=localStorage.getItem('model'); const ss=localStorage.getItem('specialty'); const sai=localStorage.getItem('allowInference');
      const m=el('model'); const s=el('specialty'); const ai=el('allowInference');
      if(m && sm && Array.from(m.options).some(o=>o.value===sm)) m.value=sm;
      if(s && ss && Array.from(s.options).some(o=>o.value===ss)) s.value=ss;
      if(ai && sai!==null) ai.checked=(sai==='1');
    }catch(e){}
  }

  
async function genAndSave(){
  const status=document.getElementById('status'); if(status) status.textContent='Generating…';
  try{
    const payload=buildPayload();
    const rA=await fetch('/api/generate-soap-json-annotated',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const jA=await rA.json();
    const d=jA && (jA.data||jA);
    const S=d?.Subjective||'Not provided';
    const O=d?.Objective||'Not provided';
    const A=d?.Assessment||'Not provided';
    const P=d?.Plan||'Not provided';
    const text=`Subjective:\n${S}\n\nObjective:\n${O}\n\nAssessment:\n${A}\n\nPlan:\n${P}\n`;
    (document.getElementById('soapTextOut')||document.getElementById('jsonOut')).textContent=text;
    if(typeof showICD==='function') showICD(jA.icd||[]);
    const rS=await fetch('/api/save-note',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...payload,data:d})});
    const jS=await rS.json();
    const dl=document.getElementById('downloads');
    if (jS?.ok && dl){ dl.innerHTML=`<a class="button" href="${jS.files.text}" target="_blank">Download Text</a> <a class="button" href="${jS.files.json}" target="_blank">Download Data</a>`; }
  }catch(e){
    (document.getElementById('soapTextOut')||document.getElementById('jsonOut')).textContent='Error: '+e.message;
  } finally {
    const status=document.getElementById('status'); if(status) status.textContent='';
  }
}
document.addEventListener('DOMContentLoaded', ()=>{

    const hpi=el('rawText');
    const hx=el('patientHistory');
    if(hpi) hpi.addEventListener('input', autofillFromHPI);
    if(hx)  hx.addEventListener('input', autofillFromHPI);
    
    const hpi2=el('rawText');
    if(hpi2) hpi2.addEventListener('keydown', (e)=>{ if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); genAndSave(); }});
if(hpi) hpi.addEventListener('keydown', function(e){
      if(e.key==='Enter' && !e.shiftKey && !e.ctrlKey && !e.metaKey){
        e.preventDefault();
        (async()=>{ await generate(); const sn=el('saveNote'); if(sn) sn.click(); })();
      }
    });
    const m=el('model'); const s=el('specialty'); const ai=el('allowInference');
    if(m) m.addEventListener('change', savePrefs);
    if(s) s.addEventListener('change', savePrefs);
    if(ai) ai.addEventListener('change', savePrefs);
    loadPrefs();
    setTimeout(loadPrefs, 300);
    setTimeout(autofillFromHPI, 0);
    const out=outEl(); if(out){ out.style.whiteSpace='pre-wrap'; out.style.overflowWrap='anywhere'; out.style.maxWidth='100%'; out.style.background='#fff'; }
  });
})();


(function(){
  document.addEventListener('DOMContentLoaded',function(){
    var gen=document.getElementById('genJson');
    if(gen){ gen.style.display='none'; }
    var cc=document.getElementById('rawText');
    if(cc) cc.addEventListener('keydown',function(e){
      if(e.key==='Enter' && !e.shiftKey){
        e.preventDefault();
        var g=document.getElementById('genJson'); if(g) g.click();
        setTimeout(function(){ var sn=document.getElementById('saveNote'); if(sn) sn.click(); },200);
      }
    });
  });
})();


async function streamAndSave(){
  const status=document.getElementById('status'); if(status) status.textContent='Streaming...';
  try{
    const payload = window.buildPayload();
    const r=await fetch('/api/generate-soap-stream',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const reader=r.body.getReader();
    const dec=new TextDecoder();
    const out=document.getElementById('soapTextOut')||document.getElementById('jsonOut');
    let buf=''; let raf=null;
    function paint(){ if(!raf){ raf=requestAnimationFrame(function(){ raf=null; if(out) out.textContent=buf; }); } }
    for(;;){
      const {done,value}=await reader.read();
      if(done) break;
      buf+=dec.decode(value,{stream:true});
      paint();
    }
    if(out) out.textContent=buf;

    const icdBox=document.getElementById('icdOut');
    try{
      const icdResp=await fetch('/api/icd-suggest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:buf,limit:8})});
      const icdJ=await icdResp.json();
      const icd=icdJ.icd||[];
      if(icdBox) icdBox.innerHTML = icd.length ? '<ul>'+icd.map(x=>'<li><b>'+x.code+'</b> — '+x.term+'</li>').join('')+'</ul>' : 'No suggestions.';
    }catch{ if(icdBox) icdBox.textContent=''; }

    const parsed=parseSoapText(buf);
    const saved=await fetch('/api/save-note',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.assign({},payload,{data:parsed}))}).then(x=>x.json()).catch(()=>null);
    const d=document.getElementById('downloads');
    if(d && saved && saved.ok){ d.innerHTML='<a class="button" href="'+saved.files.text+'" target="_blank">Download Text</a> <a class="button" href="'+saved.files.json+'" target="_blank">Download Data</a>'; }
  }catch(e){
    const out=document.getElementById('soapTextOut')||document.getElementById('jsonOut');
    if(out) out.textContent='Error: '+e.message;
  }finally{
    if(status) status.textContent='';
  }
}
document.addEventListener('DOMContentLoaded',function(){
  var h=document.getElementById('rawText');
  if(h){ h.addEventListener('keydown',function(e){ if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); streamAndSave(); } }); }
});

function parseSoapText(t){
  const x=String(t||'');
  const out={Subjective:'',Objective:'',Assessment:'',Plan:''};
  let cur=null;
  x.split(/\r?\n/).forEach(line=>{
    const m=line.match(/^\s*(Subjective|Objective|Assessment|Plan)\s*:\s*$/i);
    if(m){ cur=m[1][0].toUpperCase()+m[1].slice(1).toLowerCase(); return; }
    if(cur){ out[cur]+= (out[cur]?'\n':'') + line; }
  });
  for(const k of Object.keys(out)){ const v=(out[k]||'').trim(); out[k]=v? v : 'Not provided'; }
  return out;
}
