import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import PDFDocument from 'pdfkit';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const publicDir = path.join(__dirname, '..', 'public');

app.use(express.json({ limit: '1mb' }));
app.use((req,res,next)=>{ res.set('X-Marker','ONEPAGE-PIN'); next(); });

app.use(express.static(publicDir, { fallthrough: true }));

app.get('/', (req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

app.get('/health', (req,res)=>{ res.json({ status: 'ok' }); });

app.post('/pdf', (req,res)=>{
  const filename = typeof req.body?.filename === 'string' && req.body.filename.trim() ? req.body.filename.trim() : 'soap-note.pdf';
  const title = typeof req.body?.title === 'string' ? req.body.title : 'SOAP Note';
  const body = typeof req.body?.body === 'string' ? req.body.body : '';
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${filename.replace(/[^A-Za-z0-9._-]/g,'_')}"`);
  const doc = new PDFDocument({ autoFirstPage: true, size: 'LETTER', margin: 54 });
  doc.on('error', () => { try { res.end(); } catch(e) {} });
  doc.pipe(res);
  doc.fontSize(18).text(title, { underline: true });
  doc.moveDown();
  doc.fontSize(12).text(body);
  doc.end();
});

const port = process.env.PORT || 3002;
app.listen(port, () => console.log(`SOAP Notes app ready at http://127.0.0.1:${port}`));
